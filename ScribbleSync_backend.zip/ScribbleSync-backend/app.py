from flask import Flask, request, jsonify
from flask_cors import CORS
from recogniser import recognize
from feedback_generator import generate_feedback

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

@app.route('/recognize', methods=['POST'])
def recognize_text():
    data = request.get_json()
    base64_img = data.get('image')
    if not base64_img:
        return jsonify({'error': 'Image missing'}), 400

    # Process the image
    text = recognize(base64_img)
    return jsonify({'text': text})

@app.route('/feedback', methods=['POST'])
def get_feedback():
    data = request.get_json()
    input_text = data.get('text')
    if not input_text:
        return jsonify({'error': 'Text missing'}), 400

    suggestion = generate_feedback(input_text)
    return jsonify({'suggestion': suggestion})

@app.route('/simulate', methods=['POST'])
def simulate_pipeline():
    data = request.get_json()
    base64_img = data.get('image')
    if not base64_img:
        return jsonify({'error': 'Image missing'}), 400

    text = recognize(base64_img)
    suggestion = generate_feedback(text)

    return jsonify({'text': text, 'suggestion': suggestion})

if __name__ == '__main__':
    app.run(debug=True)

