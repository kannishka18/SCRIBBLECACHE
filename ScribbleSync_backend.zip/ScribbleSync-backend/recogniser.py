# recognizer.py
import tensorflow as tf
import numpy as np
from PIL import Image
import io
import base64

# Load the trained model
model = tf.keras.models.load_model('emnist_cnn_optimized.keras')

def recognize(base64_img):
    # Decode the base64 string into image data
    img_data = base64.b64decode(base64_img.split(',')[1])  # Skip the data URL part
    img = Image.open(io.BytesIO(img_data)).convert('L').resize((28, 28))  # Resize to expected size
    img_arr = np.array(img).reshape(1, 28, 28, 1) / 255.0  # Normalize and reshape

    # Make prediction
    preds = model.predict(img_arr)
    char_idx = np.argmax(preds[0])  # Get the character with the highest probability
    recognized_char = chr(char_idx + ord('a'))  # Adjust based on model output

    return recognized_char

